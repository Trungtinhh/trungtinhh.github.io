
	<div class="header_bottom">
		<div class="header_bottom_left">
			<div class="section group">
				<?php
					$getLastestRocket = $product->getLastestRocket();
					if($getLastestRocket){
						while($resultRocket=$getLastestRocket->fetch_assoc()){
				?>
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						  <a href="details.php?proid=<?php echo $resultRocket['productId']?>"><img src="admin/uploads/<?php echo $resultRocket['image']?>" alt="" / ></a>
					</div>
				    <div class="text list_2_of_1">
						<h2>ROCKET 1H</h2>
						<p><?php echo $resultRocket['productName']?></p>
						<div class="button"><span><a href="details.php?proid=<?php echo $resultRocket['productId']?>">Thêm vào giỏ</a></span></div>
				   </div>
			   </div>
			   <?php
			   	}}
			   ?>
			   <?php
					$getLastestDHGPharma = $product->getLastestDHGPharma();
					if($getLastestDHGPharma){
						while($resultDHGPharma=$getLastestDHGPharma->fetch_assoc()){
				?>		
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						  <a href="details.php?proid=<?php echo $resultDHGPharma['productId']?>"><img src="admin/uploads/<?php echo $resultDHGPharma['image']?>" alt="" / ></a>
					</div>
					<div class="text list_2_of_1">
						  <h2>DHG Pharma</h2>
						  <p><?php echo $resultDHGPharma['productName']?></p>
						  <div class="button"><span><a href="details.php?proid=<?php echo $resultDHGPharma['productId']?>">Thêm vào giỏ</a></span></div>
					</div>
				</div>
				<?php
			   	}}
			   ?>
			</div>

			<div class="section group">
				<?php
					$getLastestKINOHIMITSU = $product->getLastestKINOHIMITSU();
					if($getLastestKINOHIMITSU){
						while($resultKINOHIMITSU=$getLastestKINOHIMITSU->fetch_assoc()){
				?>	
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						 <a href="details.php?proid=<?php echo $resultKINOHIMITSU['productId']?>"> <img src="admin/uploads/<?php echo $resultKINOHIMITSU['image']?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
						<h2 style="font-size: 16px;">KINOHIMITSU</h2>
						<p><?php echo $resultKINOHIMITSU['productName']?></p>
						<div class="button"><span><a href="details.php?proid=<?php echo $resultKINOHIMITSU['productId']?>">Thêm vào giỏ</a></span></div>
				   </div>
			   </div>	
			   <?php
			   	}}	
			   ?>	
			   <?php
					$getLastestSanofi = $product->getLastestSanofi();
					if($getLastestSanofi){
						while($resultSanofi=$getLastestSanofi->fetch_assoc()){
				?>
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						  <a href="details.php?proid=<?php echo $resultSanofi['productId']?>"><img src="admin/uploads/<?php echo $resultSanofi['image']?>" alt="" /></a>
					</div>
					<div class="text list_2_of_1">
						  <h2>Sanofi</h2>
						  <p><?php echo $resultSanofi['productName']?></p>
						  <div class="button"><span><a href="details.php?proid=<?php echo $resultSanofi['productId']?>">Thêm vào giỏ</a></span></div>
					</div>
				</div>
				<?php
			   	}}	
			   ?>
			</div>
		  <div class="clear"></div>
		</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<?php
	      					$product_featured = $product->getproduct_featured();
	      					if($product_featured){
	      						while($result = $product_featured->fetch_assoc()){
	      		
	      				?>
						<li><a href="details.php?proid=<?php echo $result['productId']?>"><img src="admin/uploads/<?php echo $result['image']?>" alt="" style=" height:110px;"/></a></li>
						
						<?php 
							}
						}
						?>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>

</div>
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
					<table>
					<tr>
					<td>	
					<div class="div1" style="width:300px; ">	
						<h4>Liên hệ</h4>
						<ul>
							<li><span>+84-1234567789</span></li>
							<li><span>+84-0123456789</span></li>
						</ul>
					</div>
					</td>
					<td>
					<div class="div1" style="width:300px;">
								<h4>Địa chỉ</h4>
								<ul>
									<li><span>Chi nhánh 1: 137, QL 1A, thị trấn Cái Tắc, Hậu Giang</span></li>
									<li><span>Chi nhánh 2: 276, 3/2, Ninh Kiều, Cần Thơ</span></li>
								</ul>	
					</div>
					</td>
					<td>
					<div class="div1" style="width:300px;">
								<h4>Bản đồ</h4>
								<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3929.0071136413144!2d105.76049743492375!3d10.016270406143203!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1svi!2s!4v1608899953885!5m2!1svi!2s" width="100%" height="200" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
					</div>
					</td>
					</tr>

					</table>
						<div class="social-icons">
							<h4>Theo dõi chúng tôi</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
					
			</div>
			</div>
			<div class="copy_right">
				<p>Dương Trung Tính B1706880</p>
		   </div>
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
</body>
</html>

<?php include 'inc/header.php';?>

<!-- ket thuc slider -->
<?php
    if(!isset($_GET['catid']) || $_GET['catid'] == NULL){
        echo "<script>window.location = '404.php'</script>";
    }else{
        $id = $_GET['catid'];
    }
    // if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //     $catName = $_POST['catName'];
    //     $updateCat = $cat->update_category($catName, $id);
    // }

?>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<?php
	      		$name_cat = $cat->get_name_by_cat($id);
	      		if($name_cat){
	      		$result_name = $name_cat->fetch_assoc();
	      	?>
    		<div class="heading">
    		<h3>Danh mục: <?php echo $result_name['catName']?></h3>
    		</div>
    		<?php 
				}else{
				echo "Danh mục chưa có sản phẩm !";
			}
			?>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
	      	<?php
	      		$getproductbycat = $cat->get_product_by_cat($id);
	      		if($getproductbycat){
	      			while($result = $getproductbycat->fetch_assoc()){
	      	?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="preview-3.php"><img src="admin/uploads/<?php echo $result['image'];?>" width="200px" height="150px" alt="" /></a>
					 <h2><?php echo $result['productName'];?> </h2>
					 <p><?php echo $fm->textShorten($result['product_desc'],10);?></p>
					 <p><span class="price"><?php echo $result['price'];?></span></p>
				     <div class="button"><span><a href="details.php?proid=<?php echo $result['productId'];?>" class="details">Chi tiết</a></span></div>
				</div>
			<?php 
				}
			}
			?>
			</div>

	
	
    </div>
 </div>
</div>
<?php include 'inc/footer.php';?>
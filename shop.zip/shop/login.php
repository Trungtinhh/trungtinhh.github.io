<?php include 'inc/header.php';?>

<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){
        $insertCustomer = $cs->insert_customer($_POST);
        
    }
    
?>
<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])){
        $login_Customer = $cs->login_customer($_POST);
    }
    
?>
 <div class="main">
    <div class="content">
    	 <div class="login_panel">
        	<h3>Đăng nhập</h3>
        	<p>Điền thông tin đăng nhập dưới đây: </p>
        	<form action="" method="POST">
                	<input type="text" name="email" class="field" placeholder="Email">
                    <input type="password" name="password" class="field" placeholder="Mật khẩu">
                    <br/>
                    <br/>
                    <div class="buttons"><div><input type="submit" name="login" class="grey" value="Đăng nhập"/></div></div>
             </form>
        </div>

        <?php
        	
        ?>

    	<div class="register_account">
    		<h3>Tạo tài khoản mới: </h3>
    		<?php 
    			if(isset($insertCustomer)){
    				echo $insertCustomer;
    			}
    		?>
    		<form action="" method="POST">
		   			 <table>
		   				<tbody>
						<tr>
						<td>
							<div>
							<input type="text" name="name" placeholder="Nhập tên..." >
							</div>
							
							<div>
							   <input type="text" name="city" placeholder="Nhập thành phố...">
							</div>
							
							<div>
								<input type="text" name="zipcode" placeholder="Nhập Zipcode...">
							</div>
							<div>
								<input type="text" name="email" placeholder="Nhập E-mail...">
							</div>
		    			 </td>
		    			<td>
						<div>
							<input type="text" name="address" placeholder="Nhập địa chỉ...">
						</div>
		    		<div>
						<select id="country" name="country" onchange="change_country(this.value)" class="frm-field required" >
							<option value="null">Quốc gia</option>         
							<option value="VN">Việt Nam</option>
		         </select>
				 </div>		        
	
		           <div>
		          <input type="text" name="phone"  placeholder="Nhập SĐT...">
		          </div>
				  
				  <div>
					<input type="text" name="password" placeholder="Nhập mật khẩu...">
				</div>
		    	</td>
		    </tr> 
		    </tbody></table> 
		   <div class="search"><div><input type="submit" name="submit" class="grey" value="Tạo tài khoản"></div></div>
		    <p class="terms">Bằng cách nhấp chuột bạn đã đồng ý với  <a href="">Điều khoản &amp; Điều kiện</a> của chúng tôi.</p>
		    <div class="clear"></div>
		    </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
</div>
  <?php include 'inc/footer.php';?>
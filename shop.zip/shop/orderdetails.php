<?php
	include 'inc/header.php';
	//include 'inc/slider.php';
?>
<!--  <?php
	if(isset($_GET['orderid']) && $_GET['orderid'] =='order'){
  		$customer_id = Session::get('customer_id');
  		$insertOrder = $ct->insertOrder($customer_id);
  	}
	?>  -->
<style>
	.box_left{
		border:1px solid #666;
		float:left;
		padding:4px;
	}
	
	.order_href{
		width:17%;
		padding:10px 50px;
		border: none;
		background:red;
		font-size:23px;
		
		margin-bottom:10px;
		cursor: pointer;
	}
</style>
<form action="" method="POST">
 <div class="main">
    <div class="content">
    	<div class="section group">
    	<div class="heading">
    		<h3>Lịch sử mua hàng</h3>
            
    		<div class="clear">
    		<div class="box_left">
    			<div class="cartpage">
			    	
						<table  class="tblone">
							<tr>
								<th width="5%">ID</th>
								<th width="15%">Tên sản phẩm</th>
								<th width="15%">Hình ảnh</th>
								<th width="15%">Giá</th>
								<th width="10%">Số lượng</th>
								<th width="20%">Thành tiền</th>
								<th width="20%">Thời gian mua</th>
							</tr>
							<?php
								$get_order = $ct->get_order();
								$i=0;
								if($get_order){
									while($result = $get_order->fetch_assoc()){
										$i++;

							?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $result['productName']?></td>
								<td><img src="admin/uploads/<?php echo $result['image']?>"></td>
								<td><?php echo $result['price']."."."VND"?></td>
								<td><?php echo $result['quantumty']?></td>
								<td><?php
									 $total = $result['price'] * $result['quantumty'];
									 echo $total.'.'.'VND';
								?></td>
								<td><?php echo $result['date_order']?></td>
								<?php
									Session::set('date_old', $result['date_order'])
								?>
							</tr>
							<?php
							}
							}else{
								echo "<td colspan='6' style='text-align:center; color:red; font-size:35px;' >TRỐNG </td>";
							}
							?>
						</table>
						<center><div class="order_href"><a  style="color:white;" href="index.php">Trang Chủ</a></div></center>
					</div>
    		</div>
 		</div>
 	</div>
 	</div>
 </div>
</form>
<?php
	include 'inc/footer.php';
?>
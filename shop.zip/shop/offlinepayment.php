<?php
	include 'inc/header.php';
	//include 'inc/slider.php';
?>
 <?php
	if(isset($_GET['orderid']) && $_GET['orderid'] =='order'){
  		$customer_id = Session::get('customer_id');
  		$insertOrder = $ct->insertOrder($customer_id);
  		$Order = $ct->add_hoadon($customer_id);
  		$ct->del_cart();
  	}
	?> 
<style>
	.box_left{
		width:60%;
		border:1px solid #666;
		float:left;
		padding:4px;
	}
	.box_right{
		width:35%;
		border:1px solid #666;
		float:right;
		padding:4px;
	}
	.order_href{
		width:17%;
		padding:10px 50px;
		border: none;
		background:red;
		font-size:23px;
		color:#fff;
		margin-bottom:10px;
		cursor: pointer;
	}
</style>
<form action="" method="POST">
 <div class="main">
    <div class="content">
    	<div class="section group">
    	<div class="heading">
    		<h3>Thanh toán trực tiếp </h3>
    		<?php
    			if(isset($insertOrder)){
    				echo $insertOrder;
    			}
    		?>
    		</div>
            
    		<div class="clear">
    		<div class="box_left">
    			<div class="cartpage">
			    	
			    	<?php
			    		if(isset($update_quantumty_cart)){
			    			echo $update_quantumty_cart;
			    		}
			    	?>
			    	<?php
			    		if(isset($delcart_quantumty_cart)){
			    			echo $delcart_quantumty_cart;
			    		}
			    	?>
						<table  class="tblone">
							<tr>
								<th width="5%">ID</th>
								<th width="15%">Tên sản phẩm</th>
								<th width="15%">Giá</th>
								<th width="25%">Số lượng</th>
								<th width="20%">Thành tiền</th>
							</tr>
							<?php
								$get_product_cart = $ct->get_product_cart();
								$subtotal = 0;
								$qty = 0;
								$i=0;
								if($get_product_cart){
									while($result = $get_product_cart->fetch_assoc()){
										$i++;
							?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $result['productName']?></td>
								<td><?php echo $result['price']."."."VND"?></td>
								<td><?php echo $result['quantumty']?></td>
								<td><?php
									 $total = $result['price'] * $result['quantumty'];
									 echo $total.'.'.'VND';
								?></td>
							</tr>
							<?php
							$subtotal += $total; 
								}
							}else{
								echo '<tr><td colspan="6" style="color:red;">Giỏ hàng trống. Vui lòng thêm sản phẩm!</td></tr>';
							}
							?>
						</table>
						<table style="float:right;text-align:left;" width="40%">
							<tr>
								<th>Tổng tiền : </th> 
								<td><?php echo $subtotal.'.'.'VND';
										 
								?></td>
							</tr>
							<tr>
								<th>Thuế (VAT) : </th>
								<td><?php
									echo ($subtotal * 10 / 100).'.'.'VND';
								?></td>
							</tr>
							<tr>
								<th>Tổng tiền phải trả :</th>
								<td><?php
									 $tt = $subtotal + ($subtotal * 10 / 100);
									 echo $tt.'.'.'VND';
									 Session::set('sum',$tt);
								?> </td>
							</tr>
					   </table>
					</div>
    		</div>
    		<div class="box_right">
    			<table class="tblone">
    		<?php 
    			$id = Session::get('customer_id');
    			$get_customers = $cs->show_customers($id);
    			if($get_customers){
    				while($result = $get_customers->fetch_assoc()){

    		?>
    		<tr>
    			<td style="text-align: left;">Tên</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['name']?></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">Thành phố</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['city']?></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">Số điện thoại</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['phone']?></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">Quốc gia</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['country']?></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">Zip-code</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['name']?></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">E-mail</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['email']?></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">Địa chỉ</td>
    			<td style="text-align: left;">:</td>
    			<td style="text-align: left;"><?php echo $result['address']?></td>
    		</tr>
    		<tr>
    			<td colspan="3"><a href="editprofile.php">Cập nhật</a></td>
    		</tr>
    		<?php
    			}}
    		?>
    		
    	</table>
    		</div>
 		</div>
 	</div>
 	</div>
 		<center><div class="order_href"><a href="?orderid=order" >Đặt hàng</a></div> </center><br/>
 		<div style="text-align: center; margin-bottom:10px;"> <a style="color:red;" href="orderdetails.php"> Nhấp vào để xem lịch sử mua hàng </a></div>
 </div>
</form>
<?php
	include 'inc/footer.php';
?>
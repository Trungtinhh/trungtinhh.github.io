<?php
	include 'inc/header.php';
	//include 'inc/slider.php';
?>
<?php
	$login_check=Session::get('customer_login');
	if($login_check==false){
		header('Location:login.php');
	}
?>
 <?php
	// if(!isset($_GET['proid']) || $_GET['proid'] == NULL){
 //        echo "<script>window.location = './404.php'</script>";

 //    }else{
 //             $id = $_GET['proid'];
 //    }
    // $pd = new product();
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save'])){
    	$id = Session::get('customer_id');
        $UpdateCustomers = $cs->update_customers($_POST, $id);
    }
?> 
 <div class="main">
    <div class="content">
    	<div class="section group">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Cập nhật thông tin người dùng: </h3>
    		</div>
    		<div class="clear"></div>
    	</div>
        <form action="" method="POST">
    	<table class="tblone">
            <tr rowspan="2">
                <?php
                if(isset($UpdateCustomers)){
                    echo '<td colspan="3">'.$UpdateCustomers.'</td>';
                }
                ?>
            </tr>
    		<?php 
    			$id = Session::get('customer_id');
    			$get_customers = $cs->show_customers($id);
    			if(isset($get_customers)){
    				while($result = $get_customers->fetch_assoc()){

    		?>
    		<tr>
    			<td style="text-align: left;">Tên</td>
    			<td style="text-align: left;">:</td>
                <td ><input type="text" name="name" value="<?php echo $result['name']?>"></td>
    		</tr>
    		<!-- <tr>
    			<td style="text-align: left;">Thành phố</td>
    			<td style="text-align: left;">:</td>
    			<td ><input type="text" name="city" value="<?php echo $result['city']?>"></td>
    		</tr> -->
    		<tr>
    			<td style="text-align: left;">Số điện thoại</td>
    			<td style="text-align: left;">:</td>
    			<td ><input type="text" name="phone" value="<?php echo $result['phone']?>"></td>
    		</tr>
    		<!-- <tr>
    			<td style="text-align: left;">Quốc gia</td>
    			<td style="text-align: left;">:</td>
    			<td ><input type="text" name="country" value="<?php echo $result['country']?>"></td>
    		</tr> -->
    		<tr>
    			<td style="text-align: left;">Zip-code</td>
    			<td style="text-align: left;">:</td>
    			<td ><input type="text" name="zipcode" value="<?php echo $result['zipcode']?>"></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">E-mail</td>
    			<td style="text-align: left;">:</td>
    			<td ><input type="text" name="email" value="<?php echo $result['email']?>"></td>
    		</tr>
    		<tr>
    			<td style="text-align: left;">Địa chỉ</td>
    			<td style="text-align: left;">:</td>
    			<td ><input type="text" name="address" value="<?php echo $result['address']?>"></td>
    		</tr>
    		<tr>
    			<td colspan="3"><input type="submit" name="save" value="save" class="grey "></td>
    		</tr>
    		<?php
    			}}
    		?>
    		
    	</table>
    </form>
 		</div>
 	</div>
<?php
	include 'inc/footer.php';
?>
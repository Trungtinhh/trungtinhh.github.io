<?php include 'inc/header.php'?>

<div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">
						<div class="not_found">
							<h3>Page doesn't found</h3>
					</div>
					
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
</div>
 <?php include 'inc/footer.php'?>
-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 29, 2020 lúc 03:27 AM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `banthuoc`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminPass` varchar(255) NOT NULL,
  `level` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `admin`
--

INSERT INTO `admin` (`adminId`, `adminName`, `adminEmail`, `adminUser`, `adminPass`, `level`) VALUES
(6, 'Trung Tính', 'tinh@gmail.com', 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `brand`
--

CREATE TABLE `brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `brand`
--

INSERT INTO `brand` (`brandId`, `brandName`) VALUES
(9, 'DHG Pharma'),
(17, 'Sanofi'),
(19, 'Rocket 1h'),
(20, 'KINOHIMITSU'),
(21, 'Kirkland'),
(22, 'Quang Minh & Wa Pharma USA (Việt Nam)'),
(23, 'Menarini (Ý)'),
(24, 'Hasan (Việt Nam)'),
(25, 'United (Việt Nam)');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `cartId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `quantumty` int(11) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`catId`, `catName`) VALUES
(9, 'Thực phẩm chức năng'),
(10, 'Giảm đau & Hạ sốt'),
(11, 'Kháng sinh'),
(12, 'Kê đơn'),
(13, 'Dùng ngoài da');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `zipcode` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`id`, `name`, `address`, `city`, `country`, `zipcode`, `phone`, `email`, `password`) VALUES
(4, 'trungtinh', 'can tho', 'tra vinh', 'VN', 'scjaoasi', '123134123', 'tinh@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoadon`
--

CREATE TABLE `hoadon` (
  `id` int(11) NOT NULL,
  `id_Kh` varchar(255) NOT NULL,
  `sl` int(11) NOT NULL,
  `tonggia` int(11) NOT NULL,
  `ngay` timestamp NOT NULL DEFAULT current_timestamp(),
  `trangthai` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `hoadon`
--

INSERT INTO `hoadon` (`id`, `id_Kh`, `sl`, `tonggia`, `ngay`, `trangthai`) VALUES
(13, '4', 2, 346, '2020-12-28 08:55:11', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `type` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`productId`, `productName`, `catId`, `brandId`, `product_desc`, `type`, `price`, `image`) VALUES
(20, 'ATICEF 250', 11, 9, '<p>CHỈ ĐỊNH: Điều trị nhiễm khuẩn từ nhẹ đến vừa do c&aacute;c vi khuẩn nhạy cảm bao gồm:</p>\r\n<p>* Nhiễm khuẩn đường h&ocirc; hấp:</p>\r\n<p>- Vi&ecirc;m amidan, vi&ecirc;m họng, vi&ecirc;m tai giữa, vi&ecirc;m mũi - xoang, vi&ecirc;m thanh quản.</p>\r\n<p>- Vi&ecirc;m phế quản - phổi, vi&ecirc;m phổi th&ugrave;y, vi&ecirc;m phế quản cấp v&agrave; mạn t&iacute;nh, &aacute;p xe phổi, vi&ecirc;m mủ m&agrave;ng phổi, vi&ecirc;m m&agrave;ng phổi.</p>\r\n<p>* Nhiễm khuẩn đường tiết niệu - sinh dục: Vi&ecirc;m thận - bể thận cấp v&agrave; mạn t&iacute;nh, vi&ecirc;m b&agrave;ng quang, vi&ecirc;m niệu đạo, nhiễm khuẩn phụ khoa.</p>\r\n<p>* Nhiễm khuẩn da v&agrave; m&ocirc; mềm: Nhọt, vi&ecirc;m quầng, vi&ecirc;m hạch bạch huyết, &aacute;p xe, vi&ecirc;m m&ocirc; tế b&agrave;o, lo&eacute;t do nằm l&acirc;u, vi&ecirc;m v&uacute;.</p>\r\n<p>* C&aacute;c nhiễm khuẩn kh&aacute;c: Vi&ecirc;m cơ xương, vi&ecirc;m xương tủy, vi&ecirc;m xương khớp nhiễm khuẩn, nhiễm khuẩn trong sản khoa.</p>\r\n<p>CHỐNG CHỈ ĐỊNH: Mẫn cảm với c&aacute;c kh&aacute;ng sinh nh&oacute;m cephalosporin.</p>', 0, '150 000', 'a0cf2bc5cc.png'),
(21, 'Hapacol 150', 10, 9, '<p><strong><span>CHỈ ĐỊNH:</span></strong></p>\r\n<p><span>Hạ sốt, giảm đau cho trẻ trong c&aacute;c trường hợp: cảm, c&uacute;m, sốt xuất huyết, nhiễm khuẩn, nhiễm si&ecirc;u vi, mọc răng, sau khi ti&ecirc;m chủng, sau phẫu thuật,&hellip;</span></p>\r\n<p><strong><span>CHỐNG CHỈ ĐỊNH:</span></strong><span>&nbsp;Qu&aacute; mẫn với một trong c&aacute;c th&agrave;nh phần của thuốc. Người bệnh thiếu hụt glucose - 6 - phosphat dehydrogenase.</span></p>', 0, '120 000', 'c02ae0d196.jpg'),
(22, 'ROCKET (dạng gói)', 9, 19, '<ul>\r\n<li><span>Gi&uacute;p bổ kh&iacute; huyết, bổ thận, tr&aacute;ng dương, mạnh g&acirc;n cốt, tăng cường sức đề kh&aacute;ng v&agrave; phục hồi sinh lực cho cơ quan nội tạng to&agrave;n th&acirc;n.</span></li>\r\n<li><span>Gi&uacute;p giảm cholesterol, vững bền th&agrave;nh mạnh, hỗ trợ điều trị huyết &aacute;p cao, huyết &aacute;p thấp.</span></li>\r\n<li><span>Gi&uacute;p cường tr&aacute;ng to&agrave;n th&acirc;n v&agrave; khả năng sinh dục được mạnh mẽ.</span></li>\r\n</ul>', 0, '300 000', 'ec74a4bda1.webp'),
(23, 'MACA MEN', 9, 20, '<p><span><strong>C&ocirc;ng Dụng:</strong></span></p>\r\n<ul>\r\n<li><span>Gi&uacute;p bổ thận tr&aacute;ng dương, tăng cường sinh lực, sức bền v&agrave; cải thiện hưng phấn sinh l&yacute; nam giới.</span></li>\r\n<li><span>Gi&uacute;p cải thiện t&igrave;nh trạng xuất tinh sớm, tiểu đ&ecirc;m nhiều, đau lưng mỏi gối.</span></li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><span><strong>Đối tượng sử dụng:</strong></span></p>\r\n<ul>\r\n<li><span>Đ&agrave;n &ocirc;ng độ tuổi trung ni&ecirc;n, m&atilde;n dục hoặc yếu sinh l&yacute;, c&oacute; biểu hiện l&atilde;nh cảm t&igrave;nh dục.</span></li>\r\n<li><span>Nam giới thận yếu tiểu đ&ecirc;m, đau lưng mỏi gối, người mệt mỏi.</span></li>\r\n</ul>', 1, '1 890 000', '51bf068c2a.webp'),
(24, 'GLUCOSAMIN KIRKLAND 1500MG', 9, 21, '<ul>\r\n<li>\r\n<p><span>Kirkland Glucosamine HCl 1500mg MSM&nbsp;cung cấp nguồn dưỡng chất để phục hồi, duy tr&igrave; v&agrave; t&aacute;i tạo sụn khớp, hỗ trợ điều trị cho c&aacute;c trường hợp như: Tho&aacute;i h&oacute;a xương khớp, vi&ecirc;m quanh khớp, lo&atilde;ng xương, vi&ecirc;m khớp cấp v&agrave; m&atilde;n t&iacute;nh,...</span></p>\r\n</li>\r\n<li>\r\n<p><span>Tăng cường sản xuất dịch nhầy để gi&uacute;p khớp hoạt động trơn tru, giảm t&igrave;nh trạng cứng khớp, đau nhức.</span></p>\r\n</li>\r\n<li>\r\n<p><span>Giảm&nbsp;đau khớp&nbsp;cho bệnh nh&acirc;n vi&ecirc;m khớp (*)</span></p>\r\n</li>\r\n<li>\r\n<p><span>K&iacute;ch th&iacute;ch t&aacute;i tạo m&ocirc; sụn, t&aacute;i tạo sụn khớp, từ đ&oacute; duy tr&igrave; sụn khớp khỏe mạnh, tr&aacute;nh bị hao m&ograve;n, tổn thương bởi gốc tự do.&nbsp;</span></p>\r\n</li>\r\n<li>\r\n<p><span>Duy tr&igrave; hoạt động b&igrave;nh thường của xương khớp, người bệnh khỏe mạnh hơn, hạnh ph&uacute;c hơn.</span></p>\r\n</li>\r\n</ul>', 0, '610 000', '9ad536e7ca.webp'),
(25, 'Panadol', 10, 17, '<p><span>Panadol Cảm c&uacute;m l&agrave;m giảm c&aacute;c triệu chứng của cảm c&uacute;m như sốt, đau v&agrave; xung huyết mũi.</span></p>', 0, '196 000', '2fecebe3a1.jpg'),
(27, 'Trangala A Fort 8g', 13, 22, '<p><span>Trị mụn nhọt, ghẻ lở, da nứt nẻ do trời lạnh, nước ăn ch&acirc;n, ăn tay, vi&ecirc;m da, ngứa da, phỏng. Đặc biệt trị nứt lở tay ch&acirc;n khi c&ocirc;ng nh&acirc;n l&agrave;m việc tại c&aacute;c nh&agrave; m&aacute;y chế biến hải sản v&agrave; những người phải tiếp x&uacute;c với nước nhiều.</span></p>', 1, '20 000', '25350331c7.jpg'),
(28, 'Siofor 850mg', 12, 23, '<p><span>Điều trị đ&aacute;i th&aacute;o đường kh&ocirc;ng phụ thuộc insulin (đ&aacute;i th&aacute;o đường tu&yacute;p 2) ở người trưởng th&agrave;nh v&agrave; trẻ em tr&ecirc;n 10 tuổi; gi&uacute;p hạ nồng độ đường huyết ở những bệnh nh&acirc;n b&eacute;o ph&igrave; m&agrave; đường huyết kh&ocirc;ng được kiểm so&aacute;t đầy đủ chỉ bằng chế độ ăn ki&ecirc;ng v&agrave; luyện tập.&nbsp;</span><strong>Ở người trưởng th&agrave;nh:</strong><span>&nbsp;d&ugrave;ng đơn trị liệu hoặc phối hợp với c&aacute;c thuốc chống đ&aacute;i th&aacute;o đường đường uống kh&aacute;c hay insulin.&nbsp;</span><strong>Ở trẻ em tr&ecirc;n 10 tuổi v&agrave; thanh thiếu ni&ecirc;n</strong><span>: d&ugrave;ng đơn trị liệu hoặc phối hợp với c&aacute;c thuốc chống đ&aacute;i th&aacute;o đường đường uống kh&aacute;c hay insulin.&nbsp;</span><strong>Đối với người lớn b&eacute;o ph&igrave; tiểu đường tu&yacute;p 2</strong><span>&nbsp;sau khi chế độ ăn ki&ecirc;ng thất bại, được điều trị bằng metformin như l&agrave; lựa chọn điều trị đầu ti&ecirc;n đ&atilde; cho thấy giảm tần xuất c&aacute;c biến chứng do tiểu đường.</span></p>', 0, 'Viên/2000', '8388a060c7.jpg'),
(29, 'Tilhasan 60mg', 12, 24, '<p><span>Điều trị v&agrave; dự ph&ograve;ng cơn đau thắt ngực, chủ yếu trong đau thắt ngực do gắng sức, đau tự ph&aacute;t v&agrave; đau thắt kiểu Prinzmetal. Tăng huyết &aacute;p v&ocirc; căn.</span></p>', 1, '45 000', 'b21de6513c.jpg'),
(30, 'Bisoloc 5mg ', 12, 25, '<p><span>Điều trị tăng huyết &aacute;p v&agrave; bệnh mạch v&agrave;nh (cơn đau thắt ngực). Điều trị suy tim mạn ổn định từ vừa đến nặng cho bệnh nh&acirc;n giảm chức năng t&acirc;m thu thất (ph&acirc;n suất tống m&aacute;u ổ 35%, dựa tr&ecirc;n si&ecirc;u &acirc;m tim) kết hợp với thuốc ức chế men chuyển v&agrave; lợi tiểu, v&agrave; c&aacute;c glycoside trợ tim nếu cần.</span></p>', 0, 'Viên/2100', 'b30784449e.jpg'),
(31, 'Flagyl 500mg - Sanofi Aventis', 12, 17, '<p>Nhiễm Trichomonas đường tiết niệu &ndash; sinh dục ở nam v&agrave; nữ.</p>\r\n<p>Nhiễm Giardia lambia v&agrave; nhiễm amib.</p>\r\n<p>Vi&ecirc;m lo&eacute;t miệng.</p>\r\n<p>Ph&ograve;ng ngừa nhiễm khuẩn do vi khuẩn kỵ kh&iacute;.</p>\r\n<p>Ph&ograve;ng ngừa sau phẫu thuật đường ti&ecirc;u h&oacute;a v&agrave; phẫu thuật phụ khoa.</p>', 1, 'Viên/1000', '951eb3e019.jpg'),
(32, 'Sanofi Lactacyd Milky', 13, 17, '<p><span>Chứa c&aacute;c dưỡng chất v&agrave; vitamin tự nhi&ecirc;n</span><br /><span>Bảo vệ da, kh&ocirc;ng g&acirc;y k&iacute;ch ứng cho b&eacute;</span></p>', 1, '79 000', 'ee373b51e3.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `quantumty` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date_order` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `productId`, `productName`, `customer_id`, `quantumty`, `price`, `image`, `date_order`) VALUES
(103, 25, 'Panadol', 4, 1, '196', '2fecebe3a1.jpg', '2020-12-28 08:55:11'),
(104, 20, 'ATICEF 250', 4, 1, '150', 'a0cf2bc5cc.png', '2020-12-28 08:55:11');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Chỉ mục cho bảng `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catId`);

--
-- Chỉ mục cho bảng `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `hoadon`
--
ALTER TABLE `hoadon`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productId`);

--
-- Chỉ mục cho bảng `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `brand`
--
ALTER TABLE `brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT cho bảng `category`
--
ALTER TABLE `category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `hoadon`
--
ALTER TABLE `hoadon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT cho bảng `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

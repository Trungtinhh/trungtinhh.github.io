<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
    include '../classes/cart.php';
?>
<?php
     $ct = new cart();
     if(isset($_GET['chitiet'])){
         $ngay = $_GET['chitiet'];
         $chitiethd = $ct->chitiet_hd($ngay);
         
     }

?>


        <div class="grid_10">
            <div class="box round first grid">
                <h2>Chi tiết hóa đơn: </h2>
                <div class="block">       
                    <table class="data display datatable" id="example">
					<thead>
						
						<tr>
								<th width="5%">ID</th>
								<th width="15%">Tên sản phẩm</th>
								<th width="15%">Hình ảnh</th>
								<th width="15%">Giá</th>
								<th width="10%">Số lượng</th>
								<th width="20%">Thành tiền</th>
								<th width="20%">Thời gian mua</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$show_order = $ct->chitiet_hd($ngay);
							$i = 0;
							if($show_order){
								while($result = $show_order->fetch_assoc()){
									$i++;
						?>

						
							<tr class="odd gradeX">
								<td><?php echo $i;?></td>
								<td><?php echo $result['productName']?></td>
								<td><img src="uploads/<?php echo $result['image']?>" width=60px; ></td>
								<td><?php echo $result['price']."."."VND"?></td>
								<td><?php echo $result['quantumty']?></td>
								<td><?php
									 $total = $result['price'] * $result['quantumty'];
									 echo $total.'.'.'VND';
								?></td>
								<td><?php echo $result['date_order']?></td>
							</tr>
							<?php
							}
							}
							?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<?php include 'inc/footer.php';?>


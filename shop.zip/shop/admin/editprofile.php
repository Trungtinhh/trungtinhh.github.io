<?php include_once 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>



<div class="grid_10">
    <div class="box round first grid">
        <h2>Cập nhật thông tin người quản trị: </h2>
     <?php
            $admin = new adminlogin() ;
            if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save'])){
                $id = Session::get('adminId');
                $Updateadmin = $admin->update_admin($_POST, $id);
                if($Updateadmin){
                    echo $Updateadmin;
                }
            }
                
    ?>
        <div class="block">               
         <form action="" method="POST">
        <table class="form">
            <?php 
                $id = Session::get('adminId');
                $get_admin = $admin->show_admin($id);
                if(isset($get_admin)){
                    while($result = $get_admin->fetch_assoc()){

            ?>
            <tr>
                <td><label>Tên</label></td>
                <td ><input type="text" class="medium" name="name" value="<?php echo $result['adminName']?>"></td>
            </tr>
            
            <tr>
                <td><label>E-mail</label></td>
                <td ><input type="text" class="medium" name="email" value="<?php echo $result['adminEmail']?>"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="save" value="save"></td>
            </tr>
            <?php
                }} 
            ?>
            
        </table>
        </form>
        </div>
    </div>
</div>
<?php include 'inc/footer.php';?>
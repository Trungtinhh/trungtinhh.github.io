﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2> Bảng điều khiển</h2>
                <div class="block">               
                  Chào mừng đến với Website quản lý nhà thuốc An Tâm!        
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>
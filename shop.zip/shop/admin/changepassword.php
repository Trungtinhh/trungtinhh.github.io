﻿<?php include_once 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Thay đổi mật khẩu</h2>
        <?php 
            $admin = new adminlogin();
            if(isset($_GET['doimatkhau'])){
                $mkc = $_POST['mkcu'];
                $mkm = $_POST['mkmoi'];
                $result = $admin->doiMK($mkc,$mkm);
                if($result){
                    echo $result;
                }
            }
        ?>
        <div class="block">               
         <form action="?doimatkhau" method="POST">
            <table class="form">					
                <tr>
                    <td>
                        <label>Mật khẩu cũ</label>
                    </td>
                    <td>
                        <input type="password" placeholder="Nhập mật khẩu cũ"  name = "mkcu" class="medium" />
                    </td>
                </tr>
				 <tr>
                    <td>
                        <label>Mật khẩu mới</label>
                    </td>
                    <td>
                        <input type="password" placeholder="Nhập mật khẩu mới" name="mkmoi" class="medium" />
                    </td>
                </tr>
				 
				
				 <tr>
                    <td>
                    </td>
                    <td>
                        <input type="submit" name="submit" Value="Cập nhật" />
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
</div>
<?php include 'inc/footer.php';?>
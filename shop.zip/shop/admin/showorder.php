<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
    include '../classes/cart.php';
?>
<?php
     $ct = new cart();
     if(isset($_GET['delid'])){
         $id = $_GET['delid'];
         $delorder = $ct->del_order($id);
         
     }

?>


        <div class="grid_10">
            <div class="box round first grid">
                <h2>Tất cả đơn hàng</h2>
                <div class="block"> 
                <?php
                    if(isset($delorder)){
                        echo $delorder;
                    }
                ?>       
                    <table class="data display datatable" id="example">
					<thead>
						
						<tr>
							<th>Số thứ tự</th>
							<th>Ngày</th>
							<th>Tên khách hàng</th>
							<th>Tổng số sản phẩm</th>
							<th>Tổng tiền</th>
							<th>Trạng thái</th>
							<th>Hành động</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$show_order = $ct->get_hoadon();
							$i = 0;
							if($show_order){
								while($result = $show_order->fetch_assoc()){
									$i++;
						?>

						
						<tr class="odd gradeX">

							<td><?php echo $i; ?></td>
							<td><?php echo $result['ngay']; ?></td>
							<td><?php echo $result['name']; ?></td>
							<td><?php echo $result['sl']; ?></td>
							<td><?php echo $result['tonggia']; ?></td>
							<td><?php if($result['trangthai']==1 ){echo 'Đã giao';} else{ echo 'Chưa xử lý';}?></td>
							<td><a onclick = "return confirm('Bạn chắc chắn muốn xóa không ?')" href="?delid=<?php echo $result['id'] ?>">Xóa</a></td>
						</tr>
						<?php
						}
						}
						?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<?php include 'inc/footer.php';?>


<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <li><a class="menuitem">Danh mục</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Thêm danh mục</a> </li>
                        <li><a href="catlist.php">Danh sách danh mục</a> </li>
                    </ul>
                </li>
                 <li><a class="menuitem">Thương hiệu sản phẩm</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Thêm thương hiệu</a> </li>
                        <li><a href="brandlist.php">Danh sách thương hiệu</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Sản phẩm</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Thêm sản phẩm</a> </li>
                        <li><a href="productlist.php">Danh sách sản phẩm</a> </li>
                    </ul>
                </li> 
                <li><a class="menuitem">Đơn hàng</a>
                    <ul class="submenu">
                    	<li><a href="neworder.php">Đơn hàng mới</a></li>
                        <li><a href="orderprocess.php">Đang xử lý</a> </li>
                        <li><a href="showorder.php">Tất cả đơn hàng</a> </li>
                    </ul>
                </li> 
                <li><a class="menuitem">Khách hàng</a>
                    <ul class="submenu">
                        <li><a href="customerlist.php">Danh sách khách hàng</a></li>
                        
                    </ul>
                </li> 
        </div>
    </div>
</div>
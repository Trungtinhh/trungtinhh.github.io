
<?php
	$filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>


<?php
	class cart
	{	
		private $db;
		private $fm;
		
		
		public function __construct()
		{
			$this->db = new Database();	
			$this->fm = new Format();
		}
		public function add_to_cart($quantumty, $id){

			$quantumty= $this->fm->validation($quantumty); 

			$quantumty = mysqli_real_escape_string($this->db->link, $quantumty);
			$id = mysqli_real_escape_string($this->db->link, $id);
			$sId = session_id();

			$query ="SELECT * FROM product WHERE productId = '$id'";
			$result = $this->db->select($query)->fetch_assoc();

			$image = $result['image'];
			$productName = $result['productName'];
			$price = $result['price'];

			$checkcart = "SELECT * FROM cart WHERE productId = '$id' AND sId = '$sId' ";
 			$check_cart = $this->db->select($checkcart);
 			if(mysqli_num_rows($check_cart)>0){
 				$alert = '<span style="color:red; font-size:18px;">Sản phẩm đã có sẵn trong giỏ hàng!</span>';
 				return $alert;
 			}else{

			$query_insert = "INSERT INTO cart(productId,quantumty,sId,image,price,productName) VALUES('$id','$quantumty','$sId','$image','$price','$productName')";
			$insert_cart = $this->db->insert($query_insert);

			if($result){
				header('Location:cart.php');
			}else{
				header('Location:404.php');
			
			}
			}
	}
	public function get_product_cart(){
			$sId = session_id();
			$query = "SELECT * FROM cart WHERE sId = '$sId' ";
			$result = $this->db->select($query);
			return $result;
	}
	public function update_quantumty_cart($quantumty, $cartId){
		$quantumty = mysqli_real_escape_string($this->db->link, $quantumty);
		$cartId = mysqli_real_escape_string($this->db->link, $cartId);
		$query = "UPDATE cart 
				SET quantumty = '$quantumty' 
				WHERE cartId = '$cartId'";
			$result = $this->db->update($query);
			if($result){
				header('Location:cart.php');
				$msg = "<span class='success'>Đã cập nhật!</span>";
				return $msg;
			}else{
				$msg = "<span class='error'>Không thể cập nhật!</span>";
				return $msg;
			}
	
	}
	public function del_product_cart($cartid){
		$cartid = mysqli_real_escape_string($this->db->link, $cartid);
		$query = "DELETE FROM cart WHERE cartId = '$cartid' ";
		$result = $this->db->delete($query);
		if($result){
				header('Location:cart.php');
			}else{
				$msg = "<span class='error'>Không thể xóa!</span>";
				return $msg;
			}
	}
	public function check_cart(){
		$sId = session_id();
		$query = "SELECT * FROM cart WHERE sId = '$sId' ";
		$result = $this->db->select($query);
		return $result;
	}
	public function insertOrder($customer_id){
		$sId = session_id();
		$result_order;
		$query = "SELECT * FROM cart WHERE sId = '$sId' ";
		$result = $this->db->select($query);
		if($result){
			while($result_cart=$result->fetch_assoc()){
			$productid = $result_cart['productId'];
			$productname = $result_cart['productName'];
			$quantumty = $result_cart['quantumty'];
			$price = $result_cart['price'];
			$image = $result_cart['image'];
			$insert_query = "INSERT INTO tbl_order (productId,productName,customer_id,quantumty,price,image) VALUES ('$productid','$productname','$customer_id','$quantumty','$price','$image');";
			$result_order = $this->db->insert($insert_query);
			
			}
			if(isset($result_order)){
				$alert ="<script>alert('Đang xử lý đơn hàng')</script> <?php header('Location:orderdetails.php');?>";
				return $alert;

			}else{
				$alert ="<script>alert('Đặt hàng không thành công')</script>";
				return $alert;
			}
			
		
		}
		

	}
		public function del_cart(){
			$sId = session_id();
			$query = "DELETE FROM cart WHERE sId='$sId'";
 			$del = $this->db->delete($query);
 			}
		public function get_order(){
			$query = "SELECT * FROM tbl_order ORDER BY date_order DESC";
 			$getorder = $this->db->select($query);
 			return $getorder;
 			
 			}
 	public function add_hoadon($customer_id){
 		$sId = session_id();
		$result_order;
		$tongsl=0;
		$tonggia=0;
		$query = "SELECT * FROM cart WHERE sId = '$sId' ";
		$result = $this->db->select($query);
		if($result){
			while($result_cart=$result->fetch_assoc()){
			$productid = $result_cart['productId'];
			$productname = $result_cart['productName'];
			$quantumty = $result_cart['quantumty'];
			$price = $result_cart['price'];
			$image = $result_cart['image'];
			$tongsl += $quantumty;
			$tonggia += ($price*$quantumty);
			}
			$insert_query = "INSERT INTO hoadon (id_Kh,sl,tonggia,trangthai) VALUES ('$customer_id','$tongsl','$tonggia','0');";
			$result_order = $this->db->insert($insert_query);
		
		}
			
 		}
 		public function get_new_order(){
			$query = "SELECT hoadon.*, customer.name FROM hoadon INNER JOIN customer ON hoadon.id_Kh=customer.id WHERE trangthai='0' ORDER BY ngay DESC";
 			$getorder = $this->db->select($query);
 			return $getorder;
 			
 			}
 		public function del_order($id){
			$query = "DELETE FROM hoadon WHERE id = '$id' ";
			$result = $this->db->delete($query);
			if($result){
					$alert = "<span class='success'>Xóa hóa đơn thành công</span>";
					return $alert;
			}else{
					$alert = "<span class='error'>Xóa hóa đơn không thành công</span>";
		
				}
			}
		public function xacnhan_hd($id){
			$query = "UPDATE hoadon SET trangthai='1' WHERE id='$id'";
 			$updateorder = $this->db->update($query);
 			return $updateorder;
 			
 			}
 		public function dagiao_hd($id){
			$query = "UPDATE hoadon SET trangthai='2' WHERE id='$id'";
 			$updateorder = $this->db->update($query);
 			return $updateorder;
 			
 			}
 		public function get_process_order(){
			$query = "SELECT hoadon.*, customer.name FROM hoadon INNER JOIN customer ON hoadon.id_Kh=customer.id WHERE trangthai='1' ORDER BY ngay DESC";
 			$updateorder = $this->db->update($query);
 			return $updateorder;
 			
 			}
 		public function get_hoadon(){
			$query = "SELECT hoadon.*, customer.name FROM hoadon INNER JOIN customer ON hoadon.id_Kh=customer.id ORDER BY trangthai ";
 			$getorder = $this->db->select($query);
 			return $getorder;
 			
 			}
 		public function chitiet_hd($ngay){
			$query = "SELECT * FROM tbl_order WHERE date_order = '$ngay'  ORDER BY date_order DESC";
 			$getorder = $this->db->select($query);
 			if($getorder){
 			return $getorder;
 			}
 			
 			}
	}
?>
<?php
	$filepath = realpath(dirname(__FILE__));
	// include ($filepath.'/../lib/session.php');
	// Session::checkLogin();
	include_once ($filepath.'/../lib/database.php');
	include_once ($filepath.'/../helpers/format.php');
?>

<?php
    include_once '../lib/session.php';
    Session::init();
?>
<?php
	class adminlogin
	{	
		private $db;
		private $fm;
		
		public function __construct()
		{
			$this->db = new Database();	
			$this->fm = new Format();
		}
		public function login_admin($adminUser, $adminPass){
			$adminUser = $this->fm->validation($adminUser);
			$adminPass = $this->fm->validation($adminPass);	

			$adminUser = mysqli_real_escape_string($this->db->link, $adminUser);
			$adminPass = mysqli_real_escape_string($this->db->link, $adminPass);

			if(empty($adminUser) || empty($adminPass)){
				$alert = "<span class='error'>Các trường không được để trống</span>";;
				return $alert;
			}
			else{
				$query = "SELECT * FROM admin WHERE adminUser ='$adminUser' AND adminPass = '$adminPass' LIMIT 1";
				$result = $this->db->select($query);

				if($result != false){
					$value = $result->fetch_assoc();
					Session::set('adminlogin',true);
					Session::set('adminId', $value['adminId']);
					Session::set('adminUser', $value['adminUser']);
					Session::set('adminName', $value['adminName']);
					Session::set('tenadmin',$value['adminName']);
					header('Location:index.php');
				}
				else{
					$alert = "<span class='error'>Tên tài khoản hoặc mật khẩu không đúng</span>";
					return $alert;
				}
			}
		}
		public function doiMK($mkcu, $mkmoi){

			if(empty($mkcu) || empty($mkmoi)){
				$alert = "<span class='error'>Các trường không được để trống</span>";;
				return $alert;
			}
			$query = "SELECT * FROM admin WHERE adminPass = '".md5($mkcu)."' LIMIT 1";
			$result = $this->db->select($query);
			if(!$result){
				$msg = "<span class='error'>Mật khẩu không đúng</span>";
				return $msg;
			}else{
				$update = "UPDATE admin SET adminPass='".md5($mkmoi)."' WHERE adminId = '".Session::get('adminId')."'";
				$resultupdate = $this->db->update($update);
				if($resultupdate){
					$msg = "<span class='success'>Đổi mật khẩu thành công</span>";
					return $msg;
				}
			}
		}
		public function show_admin($id){
			$query = "SELECT * FROM admin WHERE adminId = '$id'";
			$result = $this->db->select($query);
			return $result;
		}
		public function update_admin($data, $id){
			$name = mysqli_real_escape_string($this->db->link, $data['name']);
			$email = mysqli_real_escape_string($this->db->link, $data['email']);
			Session::set('tenadmin', $name);
			if($name==""||$email==""){
				$alert = "<span class='error'>Các trường không được để trống </span>";
				return $alert;
			}else{
				
				$query = "UPDATE admin SET adminName='$name',  adminEmail='$email' WHERE adminId='$id' ";
				$result = $this->db->update($query);
				if($result){

					$alert = "<span class='success'>Sửa thành công</span>";
					return $alert;
				}else{
					$alert = "<span class='error'>Không thể sửa</span>";
					return $alert;
			}
				
			}
		}
		}
	

?>
<?php 
	include 'inc/header.php';
	//include 'inc/slider.php';
?>
<?php 
	if(isset($_GET['cartid'])){
 	$cartid = $_GET['cartid'];
	$delcart = $ct->del_product_cart($cartid);
    }
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){
			$cartId = $_POST['cartId'];
	    	$quantumty = $_POST['quantumty'];
	        $update_quantumty_cart = $ct->update_quantumty_cart($quantumty, $cartId);
	        if($quantumty <=0){
	        	$delcart = $ct->del_product_cart($cartId);
	        }
	    }
?>
 <?php 
	if(!isset($_GET['id'])){
		echo "<meta http-equiv='refresh' content='0;URL=?id=live'/>";
	}
?> 
 <div class="main">
    <div class="content"
    	<div class="cartoption">		
			<div class="cartpage">
			    	<h2>Giỏ hàng</h2>
			    	<?php
			    		if(isset($update_quantumty_cart)){
			    			echo $update_quantumty_cart;
			    		}
			    	?>
			    	<?php
			    		if(isset($delcart_quantumty_cart)){
			    			echo $delcart_quantumty_cart;
			    		}
			    	?>
						<table class="tblone">
							<tr>
								<th width="20%">Tên sản phẩm</th>
								<th width="10%">Hình ảnh</th>
								<th width="15%">Giá</th>
								<th width="25%">Số lượng</th>
								<th width="20%">Thành tiền</th>
								<th width="10%">Hành động</th>
							</tr>
							<?php
								$get_product_cart = $ct->get_product_cart();
								$subtotal = 0;
								$qty = 0;
								if($get_product_cart){
									while($result = $get_product_cart->fetch_assoc()){

							?>
							<tr>
								<td><?php echo $result['productName']?></td>
								<td><img src="./admin/uploads/<?php echo $result['image']?>" alt=""/></td>
								<td><?php echo $result['price']."."."VND"?></td>
								<td>
									<form action="" method="post">
										<input type="hidden" name="cartId" value="<?php echo $result['cartId']?>"/>
										<input type="number" name="quantumty" value="<?php echo $result['quantumty']?>"/>
										<input type="submit" name="submit" min="0" value="Cập nhật"/>
										
									</form>
								</td>
								<td><?php
									 $total = $result['price'] * $result['quantumty'];
									 echo $total;
								?></td>
								<td><a href="?cartid=<?php echo $result['cartId']?>">Xóa</a></td>
							</tr>
							<?php
							$subtotal += $total; 
								}
							}else{
								echo '<tr><td colspan="6" style="color:red;">Giỏ hàng trống. Vui lòng thêm sản phẩm!</td></tr>';
							}
							?>
						</table>
						<table style="float:right;text-align:left;" width="40%">
							<tr>
								<th>Tổng tiền : </th> 
								<td><?php echo $subtotal;
										 
								?></td>
							</tr>
							<tr>
								<th>Thuế (VAT) : </th>
								<td><?php
									echo ($subtotal * 10 / 100);
								?></td>
							</tr>
							<tr>
								<th>Tổng tiền phải trả :</th>
								<td><?php
									 $tt = $subtotal + ($subtotal * 10 / 100);
									 echo $tt;
									 Session::set('sum',$tt);
								?> </td>
							</tr>
					   </table>
					</div>
					<div class="shopping">
						<div class='shopleft' style='border:1px solid; width:200px;margin-left:200px;margin-top:0px;padding:5px;font-size:18px; text-align:center; background-color:#FF9900; border-radius:7px;'>
							<a href='index.php' style='color: white;'> Tiếp tục mua sắm</a>
							</div>
						
					
					<?php
					   	$customer_login = Session::get('customer_login');
						if($customer_login == 1){
							echo "<div class='shopright' style='border:1px solid; width:200px;margin-left:600px;margin-top:40px;padding:5px;font-size:18px; text-align:center; background-color:#FF9900; border-radius:7px;'>
							<a href='offlinepayment.php' style='color: white;'> Thanh toán</a>
							</div>";
						}else{
							echo "<div class='shopright' style='border:1px solid; width:220px;margin-left:600px;padding:5px;font-size:18px; text-align:center; background-color:#FF9900; border-radius:7px;'>
							<a href='login.php' style='color: white;'> Đăng nhập để thanh toán</a>
							</div>";
						}	
					   	?>
					</div>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>

 <?php 
	include 'inc/footer.php';
?>
